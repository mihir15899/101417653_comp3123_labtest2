import React, { useState, useEffect } from 'react';
import axios from 'axios';
import WeatherDetails from './components/WeatherDetails';
import './App.css';

const App = () => {
  const [city, setCity] = useState('Toronto');
  const [weatherData, setWeatherData] = useState(null);
  const [error, setError] = useState(null);

  // Fetch weather data based on city name
  const fetchWeatherData = async () => {
    try {
      const API_KEY = process.env.REACT_APP_API_KEY;
      const API_URL = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric`;

      const response = await axios.get(API_URL);
      setWeatherData(response.data);
      setError(null);
    } catch (err) {
      setWeatherData(null);
      setError('City not found. Please try again.');
    }
  };

  // Fetch weather data when the component mounts or when city changes
  useEffect(() => {
    fetchWeatherData();
  }, []);

  // Handle search input
  const handleSearch = (e) => {
    e.preventDefault();
    fetchWeatherData();
  };

  return (
    <div className="app-container">
      <h1>Weather App</h1>
      <form onSubmit={handleSearch} className="search-form">
        <input
          type="text"
          value={city}
          onChange={(e) => setCity(e.target.value)}
          placeholder="Enter city name"
        />
        <button type="submit">Search</button>
      </form>
      {error && <p className="error">{error}</p>}
      {weatherData && <WeatherDetails weatherData={weatherData} />}
    </div>
  );
};

export default App;
