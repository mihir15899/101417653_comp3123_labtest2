# Weather App: 101398877_comp3123_labtest2

This is a simple weather application built with ReactJS. The app fetches real-time weather data from the OpenWeatherMap API and displays essential weather information for a user-specified city.

## Features

- **Dynamic Search**: Users can search for weather details of any city.
- **Real-Time Data**: Fetches current temperature, weather conditions, humidity, and wind speed.
- **Interactive UI**: Displays weather icons and responsive error handling.
- **React Features**: Implements `useState` and `useEffect` for state management and API integration.

## Installation

1. Clone the repository:

   ```bash
   git clone https://github.com/yourusername/101398877_comp3123_labtest2.git
   ```

2. Navigate to the project directory:

   ```bash
   cd 101398877_comp3123_labtest2
   ```

3. Install dependencies:

   ```bash
   npm install
   ```

4. Create a `.env` file in the root directory and add your OpenWeatherMap API key:

   ```env
   REACT_APP_API_KEY=your_api_key_here
   ```

5. Start the development server:

   ```bash
   npm start
   ```

## Usage

- Enter a city name in the search bar and click "Search" to fetch weather details.
- The app displays:
  - Current temperature
  - Weather condition description
  - Humidity percentage
  - Wind speed
  - An icon representing the current weather




## Built With

- **ReactJS**: Frontend framework
- **Axios**: For API calls
- **OpenWeatherMap API**: Weather data source
- **CSS**: Styling

## Folder Structure

```plaintext
101398877_comp3123_labtest2/
├── public/
├── src/
│   ├── App.css
│   ├── App.js
│   ├── index.js
│   └── components/
├── .env
├── package.json
├── README.md

```
